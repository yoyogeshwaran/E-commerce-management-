package com.ecommerce.main;

import org.hibernate.Session;
import org.hibernate.Transaction;
import com.ecommerce.model.Product;
import com.ecommerce.utils.HibernateUtil;

public class MainApp {
    public static void main(String[] args) {
        // Open session
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        try {
            // Fetch product with ID 1
            Product product = session.get(Product.class, 1);
            if (product != null) {
                session.delete(product);
                transaction.commit();
                System.out.println("Product deleted successfully!");
            } else {
                System.out.println("Product not found!");
            }
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
    System.out.println("Saved Category ID: " + electronics.getId());

}
